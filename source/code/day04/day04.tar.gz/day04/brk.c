#include <stdio.h>
#include <unistd.h>
#include <string.h>
int main(){
  void* pi = sbrk(0);//获取初始位置
	brk(pi+4);//分配了4字节
	brk(pi+8);//分配了4字节
	brk(pi+4);//回收了4字节
	int* p1 = pi;
	*p1 = 100;
  double* p2 = sbrk(0);
	brk(p2+1);//p2+1 移动8字节
	*p2 = 3.1;
  char* p3 = sbrk(0);
	brk(p3+10); strcpy(p3,"zhangfei");
	//p3 = "zhangfei";//错，不能改地址
	printf("%d,%lf,%s\n",*p1,*p2,p3);
	brk(p3); brk(p2); brk(p1);
}

