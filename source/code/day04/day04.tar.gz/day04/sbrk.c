#include <stdio.h>
#include <unistd.h>

int main(){
  int* p1 = sbrk(4);//分配4字节+映射1页
	int* p2 = sbrk(4);//分配4字节
	int* p3 = sbrk(4); *p3 = 100;
	printf("p1=%p,p2=%p,p3=%p\n",p1,p2,p3);
	sbrk(-4); sbrk(-4);
	printf("*p3=%d\n",*p3);//释放内存不删除数据
  int* p4 = sbrk(0);
	printf("p4=%p\n",p4);
  sbrk(4093);//4093+4 = 4097,超过1页就2页
	sbrk(-1);//只要回到1页马上解除映射
	sbrk(-4096);//全部释放后会解除映射
	printf("pid=%d\n",getpid());
	while(1);
}


