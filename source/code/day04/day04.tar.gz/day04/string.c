#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//字符串变量是字符串的首地址,直到'\0'为止
//字符串的表示方式： 1 字面值"abc"(字符串常量)
//2 char* 表示    3  char s[n]表示
int main(){
  //1 字符串的赋值  =改地址 和strcpy()改值
	char* s1 = "abc";//只读
	char s2[4] = "abc";//栈,数组是常指针,不能改指向
  s1 = "123";//y
	//strcpy(s1,"123");//n//修改只读区的内容
	//s2 = "123";//n//常指针不能改地址
	strcpy(s2,"123");//y
	printf("s1=%s\n",s1);printf("s2=%s\n",s2);
	char* s3 = malloc(4);//指向堆区
	//s3 = "abc";//错,指向只读区,堆区内存丢了
	strcpy(s3,"abc");
	printf("s3=%s\n",s3);
	free(s3);//释放只读区内存，出错
  //2 字符串的比较  ==比地址 和 strcmp()比值
	//只读常量区中,相同值的字符串地址也相同
	char* s4 = "123"; char* s5 = "123";
  char s6[4] = "123"; char s7[4] = "123";
	printf("%d\n",s4 == s5);//1
	printf("%d\n",strcmp(s4,s5)==0);//1
	printf("%d\n",s7 == s6);//0
	printf("%d\n",strcmp(s6,s7)==0);//1
	//3 字符串的拼接，比如拼接文件路径和文件名
  char* name = "ucday04.txt";
	char* path = "/home/tarena/day04";
	char buf[50] = { };
	sprintf(buf,"%s/%s",path,name);
  //strcpy(buf,path);
	//strcat(buf,"/"); strcat(buf,name);
	printf("buf=%s\n",buf);
	//4 用指针操作字符串，比如拆分字符串
  char* message = "zhangfei,25";
  char mname[20] = { };
	char age[10] = { };
	int i;
	for(i=0;*(message+i)!=',';i++);
	strncpy(mname,message,i);
	strcpy(age,message+i+1);
	//sscanf(message,"%s%s",mname,age);//,无效
	/*int flag = 1; //1代表,之前  遇到,改为0
	int i=0,pos;
  while(*message){
		if(flag){
			if(*message==','){
			  flag = 0; pos = i;
        i++; message++; continue; }
		  mname[i] = *message;
		}else{
		  age[i-pos-1] = *message;
		}
    i++;
	  message++;
	}*/
	printf("mname=%s:age=%s\n",mname,age);
	//5 字符串的长度和容量
	//长度strlen()是数据有多少
	//容量是sizeof()是 最大能放多少个
  char buf1[100] = { };
	strcpy(buf1,"123");
  printf("length=%d,size=%d\n",strlen(buf1),
		sizeof(buf1));
  //6 字符串和int/double之间的转换
	//sprintf() / sscanf()
  int a1;
  char buf2[10] = "123";
  sscanf(buf2,"%d",&a1);//字符串->int
	printf("a1=%d\n",a1);
  char buf3[10] = { };
  sprintf(buf3,"%d",a1);
	printf("buf3=%s\n",buf3);
}

