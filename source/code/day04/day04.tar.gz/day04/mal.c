#include <stdio.h>
#include <stdlib.h>

int main(){
  int a,b,c;//栈
  printf("%p,%p,%p\n",&a,&b,&c);
	int* p1 = malloc(4);//分配地址+做了映射
	int* p2 = malloc(4);//分配地址
	int* p3 = malloc(4);
	int* p4 = malloc(16*4096);
	int* p5 = malloc(16*4096);
	int* p6 = malloc(4096);
	*p1 = 100;
	printf("p1=%p,p2=%p,p3=%p\n",p1,p2,p3);
	printf("p4=%p,p5=%p,p6=%p\n",p4,p5,p6);
	//*(p1-1) = 0;//把附近数据清空了
	printf("*p1=%d\n",*p1);
	//free(p1);
	free(p6);free(p5);free(p4);
	free(p3);free(p2);free(p1);
	printf("pid=%d\n",getpid());
	printf("*p1=%d\n",*p1);
	while(1);
}

