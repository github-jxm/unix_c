#include <stdio.h>
#include <stdlib.h>

int main(){
  int* p1 = malloc(4);//分配4 映射33页
	*(p1+100) = 10;
	printf("%d\n",*(p1+100));
	//虚拟内存地址只要映射了就能使用，不需要分配
	//但在使用前还是需要分配，便于维护和管理
}


