#include <stdio.h>
#include <stdlib.h>
void myfree (char** str) {
	free (*str);
	*str = NULL;
}
int main (void) {
	char* p = malloc (50);
	myfree (&p);
	free (p);
	return 0;
}
