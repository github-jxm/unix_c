#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
struct node {
	int a;
	char s[10];
};
int main (void) {
	struct node s1;
	s1.a = 10;
	strcpy (s1.s, "zhangfei");
	int fd = open ("struct.txt", O_RDWR |
		O_CREAT | O_TRUNC, 0644);
	write (fd, &s1, sizeof (s1));
	close (fd);
	return 0;
}
