#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
void pflags (int flags) {
	struct {
		int flag;
		char const* desc;
	}	flist[] = {
		{O_RDONLY,   "只读"},
		{O_WRONLY,   "只写"},
		{O_RDWR,     "读写"},
		{O_APPEND,   "追加"},
		{O_CREAT,    "创建"},
		{O_EXCL,     "排它"},
		{O_TRUNC,    "清空"},
		{O_NOCTTY,   "非控制终端"},
		{O_NONBLOCK, "非阻塞"},
		{O_SYNC,     "同步"},
		{O_DSYNC,    "数据同步"},
		{O_RSYNC,    "读同步"},
		{O_ASYNC,    "异步"}};
	size_t i;
	for (i = 0; i < sizeof (flist) /
		sizeof (flist[0]); ++i)
		if (flist[i].flag == O_RDONLY) {
			if ((flags & O_ACCMODE) == O_RDONLY)
				printf ("%s ", flist[i].desc);
		}
		else if (flags & flist[i].flag)
			printf ("%s ", flist[i].desc);
	printf ("\n");
}
int main (void) {
	int fd = open ("flags.txt", O_RDONLY |
		O_CREAT | O_TRUNC | O_ASYNC, 0644);
	if (fd == -1) {
		perror ("open");
		return -1;
	}
	int flags = fcntl (fd, F_GETFL);
	if (flags == -1) {
		perror ("fcntl");
		return -1;
	}
	pflags (flags);
	if (fcntl (fd, F_SETFL, O_RDWR | O_APPEND |
		O_NONBLOCK) == -1) {
		perror ("fcntl");
		return -1;
	}
	if ((flags = fcntl (fd, F_GETFL)) == -1) {
		perror ("fcntl");
		return -1;
	}
	pflags (flags);
	close (fd);
	return 0;
}
