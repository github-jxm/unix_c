#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
int main (void) {
	int fd = open ("seek.txt", O_RDWR |
		O_CREAT | O_TRUNC, 0644);
	if (fd == -1) {
		perror ("open");
		return -1;
	}
	char const* text = "Hello, World !";
	if (write (fd, text, strlen (text)) == -1) {
		perror ("write");
		return -1;
	}
	// 从当前位置向文件头的方向偏移7个字节
	if (lseek (fd, -7, SEEK_CUR) == -1) {
		perror ("lseek");
		return -1;
	}
	off_t pos = lseek (fd, 0, SEEK_CUR);
	printf ("文件位置：%ld\n", pos); // 7
	text = "Linux";
	if (write (fd, text, strlen (text)) == -1) {
		perror ("write");
		return -1;
	}
	// 从文件尾向后偏移8个字节，形成了一个8字节
	// 的文件空洞
	if (lseek (fd, 8, SEEK_END) == -1) {
		perror ("lseek");
		return -1;
	}
	text = "<-这里有个洞洞";
	if (write (fd, text, strlen (text)) == -1) {
		perror ("write");
		return -1;
	}
	off_t size = lseek (fd, 0, SEEK_END);
	printf ("文件大小：%ld\n", size);
	close (fd);
	return 0;
}
