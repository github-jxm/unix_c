#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
int main (void) {
	close (STDOUT_FILENO);
	creat ("redir.txt", 0644);
	printf ("Hello, World !\n");
	return 0;
}
