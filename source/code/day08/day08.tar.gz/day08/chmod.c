#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
int main (void) {
	int fd = open ("chmod.txt", O_RDWR |
		O_CREAT | O_TRUNC, 0644);
	if (fd == -1) {
		perror ("open");
		return -1;
	}
	/* S   U   G   O
     7   6   5   6
		 421 420 401 420
		 ugt rw- r-x rw- -> rwSr-srwT
	*/
	if (fchmod (fd, 07656) == -1) {
		perror ("chmod");
		return -1;
	}
	close (fd);
	return 0;
}
