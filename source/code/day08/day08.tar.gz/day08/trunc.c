#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
int main (void) {
	int fd = open ("trunc.txt", O_RDWR |
		O_CREAT | O_TRUNC, 0644);
	if (fd == -1) {
		perror ("open");
		return 0;
	}
	char const* text = "123456789";
	if (write (fd, text, strlen (text)) == -1) {
		perror ("write");
		return -1;
	}
	close (fd);
	if (truncate ("trunc.txt", 5) == -1) {
		perror ("truncate");
		return -1;
	}
	if (truncate ("trunc.txt", 9) == -1) {
		perror ("truncate");
		return -1;
	}
	return 0;
}
