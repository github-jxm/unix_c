#include <stdio.h>
#include <unistd.h>
int main (void) {
	/*
	if (symlink ("xxx.dat", "yyy.dat") == -1) {
		perror ("symlink");
		return -1;
	}
	*/
	char buf[1024] = {};
	ssize_t bytes = readlink ("aaa.dat", buf,
		sizeof (buf));
	if (bytes == -1) {
		perror ("readlink");
		return -1;
	}
//buf[bytes] = '\0';
	printf ("%s\n", buf);
	return 0;
}
