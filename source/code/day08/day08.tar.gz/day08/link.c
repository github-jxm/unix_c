#include <stdio.h>
#include <unistd.h>
int main (void) {
	/*
	if (link ("abc.txt", "def.txt") == -1) {
		perror ("link");
		return -1;
	}
	if (unlink ("abc.txt") == -1) {
		perror ("unlink");
		return -1;
	}
	if (remove ("work/test") == -1) {
		perror ("remove");
		return -1;
	}
	if (remove ("work") == -1) {
		perror ("remove");
		return -1;
	}
	*/
	if (rename ("123.txt",
		"../123.txt") == -1) {
		perror ("rename");
		return -1;
	}
	return 0;
}
