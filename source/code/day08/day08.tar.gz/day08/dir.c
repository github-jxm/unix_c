#include <stdio.h>
#include <limits.h>
#include <sys/stat.h>
int main (void) {
	char cwd[PATH_MAX+1];
	if (! getcwd (cwd, sizeof (cwd))) {
		perror ("getcwd");
		return -1;
	}
	printf ("工作目录：%s\n", cwd);
	if (mkdir ("code", 0777) == -1) {
		perror ("mkdir");
		return -1;
	}
	if (chdir ("code") == -1) {
		perror ("chdir");
		return -1;
	}
	if (! getcwd (cwd, sizeof (cwd))) {
		perror ("getcwd");
		return -1;
	}
	printf ("工作目录：%s\n", cwd);
	/*
	if (rmdir ("code") == -1) {
		perror ("rmdir");
		return -1;
	}
	*/
	return 0;
}
