#include <stdio.h>

int main(){
  int* pi = 0x804a014;
	printf("*pi=%d\n",*pi);
}

