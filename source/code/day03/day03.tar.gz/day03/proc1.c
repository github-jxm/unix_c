#include <stdio.h>

int i = 10;
int main(){
  printf("&i=%p\n",&i);
	printf("i=%d\n",i);
	while(1);
}

