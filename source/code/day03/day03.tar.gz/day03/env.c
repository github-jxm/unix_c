#include <stdio.h>
#include <stdlib.h>

int main(){
  char* path = getenv("PATH");//系统路径
	printf("PATH:%s\n",path);
	putenv("VAR=abc");
	printf("VAR=%s\n",getenv("VAR"));//abc
	putenv("VAR=123");
	printf("VAR=%s\n",getenv("VAR"));//123
	setenv("VAR","456",0);
	printf("VAR=%s\n",getenv("VAR"));//123
	setenv("VAR","789",1);
	printf("VAR=%s\n",getenv("VAR"));//789
}

