
#include <stdio.h>

int main()
{
		printf("hello\n");
#line 500
		printf("%d\n", a);
	  return 0;
}

