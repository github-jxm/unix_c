
#ifndef __HELLO_H__
#define __HELLO_H__

struct test
{
	int a;
	int b;
};

#endif

