
#ifndef __SHOW_H__
#define __SHOW_H__
void show(int a,  char op,  int b, int c);

#endif

