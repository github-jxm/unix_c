
#ifndef __CALC_H__
#define __CALC_H__
int add(int a, int b);
int sub(int a, int b);

#endif
