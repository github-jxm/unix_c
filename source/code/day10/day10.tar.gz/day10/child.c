#include <stdio.h>

int main(){
  printf("cpid2=%d\n",getpid());
}

