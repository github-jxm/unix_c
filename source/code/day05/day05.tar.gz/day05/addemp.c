#include "emp.h"

int main(){
  struct Emp emp;
	printf("请输入员工的编号、姓名和工资\n");
	scanf("%d%s%lf",&emp.id,emp.name,&emp.sal);
  int fd = open("em.dat",
		O_RDWR|O_CREAT|O_APPEND,0666);
	if(fd==-1) perror("open"),exit(-1);
  int res = write(fd,&emp,sizeof(emp));
	if(res==-1) perror("write");
	else printf("注册成功\n");
	close(fd);
}

