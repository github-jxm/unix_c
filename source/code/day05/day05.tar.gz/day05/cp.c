#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

int main(){
  int fd1 = open("../day01.zip",O_RDONLY);
	if(fd1==-1) perror("open1"),exit(-1);
	int fd2 = open("day01cp.zip",
		O_RDWR|O_CREAT|O_TRUNC,0666);
	if(fd2==-1) perror("open2"),exit(-1);
  char buf[1024] = {};
  while(1){
	  int res = read(fd1,buf,sizeof(buf));
		if(res==0) break;
		if(res==-1) { perror("read"); break;}
		write(fd2,buf,res);//读多少就写多少
	}
  close(fd1); close(fd2);
}


