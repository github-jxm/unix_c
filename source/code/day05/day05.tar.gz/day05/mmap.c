#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>

int main(){
  void* p = mmap(NULL,//首地址内核选择
		4,//大小，不足一页的会补满一页
		PROT_READ|PROT_WRITE,//权限
		MAP_PRIVATE|MAP_ANONYMOUS,//映射物理内存
		0,0);
  if(p==MAP_FAILED) perror("mmap"),exit(-1);
	int* pi = p;
	*pi = 100;
	printf("%d\n",*pi);
	munmap(p,4);
}


