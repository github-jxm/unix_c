#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>

int main(){//打开文件的代码
  int fd = open("aa",O_RDWR|O_CREAT|O_TRUNC,
		0666);//系统在新建文件时有权限屏蔽002
	if(fd == -1) perror("open"),exit(-1);
	printf("fd=%d\n",fd);
	close(fd);//关闭文件描述符
}

