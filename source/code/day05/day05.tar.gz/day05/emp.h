#ifndef _EMP_H
#define _EMP_H
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
struct Emp{
  int id;
	char name[20];
	double sal;
};
#endif

