#include <stdio.h>
#include <unistd.h>
#include <string.h>
int main(){
  int* pi = sbrk(4);//也能返回初始位置
	*pi = 100;
	double* pd = sbrk(8);
	*pd = 1.2;
	char* pc = sbrk(10);
	strcpy(pc,"zhangfei");
	printf("%d,%lf,%s\n",*pi,*pd,pc);
	brk(pc); brk(pd); brk(pi);
}


