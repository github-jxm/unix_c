#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>

int main(){
  int fd = open("aa",O_RDWR|O_CREAT|O_TRUNC,
		0666);
	if(fd==-1) perror("open"),exit(-1);
	int res = write(fd,"hello",strlen("hello"));
	if(res==-1) perror("write"),exit(-1);
	close(fd);
  int fd2 = open("aa",O_RDONLY);//读文件
	if(fd2==-1) perror("open2"),exit(-1);
	char buf[100] = {};
	int res2=read(fd2,buf,sizeof(buf));
	printf("读到%d字节,内容:%s\n",res2,buf);
	close(fd2);//练习：用UC函数实现文件复制
}//要求写成所有文件类型都可以复制的通用版


